package org.capg.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Customer {
private int customerId;
private String firstName;
private String lastName;
private LocalDate dateOfBirth;
private String mobileNo;
private String emailId;
private Address address;
private Set<Account> account=new HashSet<>();
public Customer() {
	
}
public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String mobileNo,
		String emailId, Address address, Set<Account> account) {
	super();
	this.customerId = customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
	this.address = address;
	this.account = account;
}
public Customer(Set<Account> account) {
	super();
	this.account = account;
}
public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String mobileNo,
		String emailId, Address address) {
	super();
	this.customerId = customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
	this.address = address;
	
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", dateOfBirth=" + dateOfBirth + ", mobileNo=" + mobileNo + ", emailId=" + emailId + ", address="
			+ address + ", account=" + account + "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public LocalDate getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(LocalDate dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Set<Account> getAccount() {
	return account;
}
public void setAccount(Set<Account> account) {
	this.account = account;
}
}

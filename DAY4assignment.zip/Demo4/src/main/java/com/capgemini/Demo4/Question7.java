package com.capgemini.Demo4;
import java.util.Scanner;
public class Question7 {
	
	

	 static String LongestWord(String s) 
	    { 
		 String[] word=s.split(" ");
	        String rts=" ";
	        for(int i=0;i<word.length;i++){
	        	   if(word[i].length()>=rts.length()){
	        	      rts=word[i];
	        	   }
	        	}
	        return(rts);
	    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String str;
		System.out.println("Enter the array:");
		str=s.nextLine();
		Question7  obj=new Question7 ();
		
		System.out.println(obj.LongestWord(str));
	
    }

	}


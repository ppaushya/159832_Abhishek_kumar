package com.capgemini.Demo4;
import java.util.Scanner;
public class Question5 {
	public void ReverseOrder(String str)
	{
		char t[]=new char[str.length()];
		char p[]=new char[str.length()];
		
		int i,j=0;
		
		
		for(i=0;i<str.length();i++)
		{
			t[i]=str.charAt(i);
		}
		
		
		for(i=str.length()-1;i>=0;i--)
		{
			p[j] = t[i];
			j=j+1;
		}
		
		
		for(i=0;i<str.length();i++)
		{
			System.out.println(p[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s=new Scanner(System.in);
		String str;
		System.out.println("Enter the array:");
		str=s.next();
		s.close();
		Question5  obj=new Question5 ();
		
		obj.ReverseOrder(str);

	}

}

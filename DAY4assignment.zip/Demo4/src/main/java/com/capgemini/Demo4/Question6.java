package com.capgemini.Demo4;
import java.util.Scanner;
public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int factorial;
	      Scanner s=new Scanner(System.in);
			System.out.println("Enter the Value:");
			factorial=s.nextInt();
			s.close();
			if(factorial>1 && factorial<18)
			{
				Question6  obj=new Question6 ();
			   System.out.println("1 = "+obj.FirstFactorial(factorial));
			}
			else
			{
				System.exit(0);
			}
			
	   }
	   static int FirstFactorial(int n)
	   {
	       if(n==1){
	         return 1;
	       }
	       System.out.print(n+"*");
	       return (n * FirstFactorial(n-1));
	   }
	}



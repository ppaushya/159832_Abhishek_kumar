package com.capgemini.Demo4;
import java.util.Scanner;

public class Question4 {
	public String LetterChanges(String str)
	{
		char ch[]=new char[str.length()];
		char ch1[]=new char[str.length()];
		int pr[]=new int[str.length()];
		int pr1[]=new int[str.length()];
		int i,j;
		
		
		
		for(i=0;i<str.length();i++)
		{
			ch[i]=str.charAt(i);
		}
		
		for(i=0;i<str.length();i++) {
				pr[i] =  (int) ch[i];
		}
		
		for(i=0;i<str.length();i++)
		{
		         pr1[i]=pr[i]+1;
		         if(pr1[i]==123)
		 		{
		 			pr1[i]=97;
		 		}
		         if(pr1[i]==97)
			 		{
			 			pr1[i]=65;
			 		}
		         if(pr1[i]==101)
			 		{
			 			pr1[i]=69;
			 		}
		         if(pr1[i]==105)
			 		{
			 			pr1[i]=73;
			 		}
		         if(pr1[i]==111)
			 		{
			 			pr1[i]=79;
			 		}
		         if(pr1[i]==117)
			 		{
			 			pr1[i]=85;
			 		}
        } 
		
         
		for(i=0;i<str.length();i++)
		{
			ch1[i]=(char) pr1[i];
		}
		
		
        String st = new String(ch1); 
        return st; 
	}
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s=new Scanner(System.in);
		String str;
		System.out.println("Enter the array:");
		str=s.nextLine();
		Question4  obj=new Question4 ();
		
		System.out.println(obj.LetterChanges(str));
		

	}


	}


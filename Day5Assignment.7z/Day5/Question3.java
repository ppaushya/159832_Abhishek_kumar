package org.cap.assignment;

interface arithmenticCalculation
	{
		void division(int a, int c);
		void modules(int b, int d);
	}
	class stud implements arithmenticCalculation
	{
	String name;
	float div,mod;


	 public	void name(String n)
	{ 
			name=n; 
	}

	public void division(int a, int c)
	{ 
		div=a/c;
	}

	public void modules(int b, int d)
	{ 
		mod=b%d; 
	}

	void disp()
		{
		System.out.println("Name :"+name);
		System.out.println("Division :"+div);
		System.out.println("Modules :"+mod);
		}
	}

	public class Question3
	{
	public static void main(String args[])
		{ 
			stud s=new stud();
			s.name("Abhishek");
			s.division(145,6);
			s.modules(196,8);
			s.disp();
		}
}
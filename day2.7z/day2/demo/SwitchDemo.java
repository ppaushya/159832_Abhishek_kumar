package org.cap.demo;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char num='p';
		
		switch(num)
		{
		case 'x':
			   System.out.println("one");
			   System.out.println("block");
			break;
			
		case 'c':
			   System.out.println("two");
			   System.out.println("block");
			break;
			
		case 'a':
			   System.out.println("ten");
			   System.out.println("block");
			break;
			
		default:
			System.out.println("default");
		break;	
					
		}

	}

}

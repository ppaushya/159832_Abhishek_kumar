package org.cap.demo;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
     int num=1;
     int sum=0, count=4;
     while (num <101)
     {
    	 if (num%2==0)
    	 {   
    		 System.out.print(num+" ");
    		 sum=sum+num;
    		 count--;
    	 }
    	 if (count==0)
    	 {
    		 count=5;
    		 System.out.println();
    		 
    	 }
    	 num++;
    	 
     }
 System.out.println(sum);
     
}
}
package org.cap.loop.demo;

import java.util.Scanner;


public class assign25_2 {
	int num;
	int a;
	int b;
	int c;
	int sum=0;
	
	
public void getSum() {
	Scanner st=new Scanner(System.in);
	System.out.println("Input number:");
	num=st.nextInt();
	st.close();
}

public int calculatesum() {
			
	while (num%10>0)
	{ a=num%10;
	  sum=sum+a;
	  num=num/10;
	  
	}
	return sum;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		assign25_2 assign= new assign25_2();
		assign.getSum();
		System.out.println(assign.calculatesum());

	}

}

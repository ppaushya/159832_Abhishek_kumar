package registration;



import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private WebElement element;



	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\akuma577\\softwarenew\\chromedriver_win32\\chromedriver.exe");
		webdriver=new ChromeDriver();
	}

@Given("^Open conference registration page$")
public void open_conference_registration_page() throws Throwable {
    webdriver.get("file:///C:/Users/akuma577/Downloads/Conferencebooking/ConferenceRegistartion.html#");
	
	String title=webdriver.getTitle();
	assertEquals( "Conference Registartion", title );
	
}

@Given("^provide registration details$")

public void provide_registration_details() throws Throwable {
	//first name alert
	element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	webdriver.switchTo().alert().accept();
	Thread.sleep(1000);
	
	
	
    webdriver.findElement(By.name("txtFN")).sendKeys("SHYAM");
    //lastname alert
    
    element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	Thread.sleep(1000);
	webdriver.switchTo().alert().accept();
    
    
    
    webdriver.findElement(By.name("txtLN")).sendKeys("MALI");
    
    //Email Alert
    element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	Thread.sleep(1000);
	webdriver.switchTo().alert().accept();
    
    
    webdriver.findElement(By.name("Email")).sendKeys("shyam@gmail.com");
    
    
    
    //phone no ALERT
    element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	element.click();
	Thread.sleep(1000);
	webdriver.switchTo().alert().accept();
    
    
    
    webdriver.findElement(By.name("Phone")).sendKeys("8968696949");
    //webdriver.findElement(By.name("txtFN")).sendKeys("SHYAM");
    org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(webdriver.findElement(By.name("size")));
    select.selectByIndex(3);
    Thread.sleep(1000);
    webdriver.findElement(By.name("Address")).sendKeys("ramnagar");
    Thread.sleep(1000);
    webdriver.findElement(By.name("Address2")).sendKeys("gharbar");
    Thread.sleep(1000);
    org.openqa.selenium.support.ui.Select city =new org.openqa.selenium.support.ui.Select(webdriver.findElement(By.name("city")));
    city.selectByIndex(1);
    org.openqa.selenium.support.ui.Select state = new org.openqa.selenium.support.ui.Select(webdriver.findElement(By.name("state")));
    state.selectByIndex(1);
    Thread.sleep(1000);
    webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();
    Thread.sleep(1000);
}

@When("^Submit validate login details and click next$")
public void submit_validate_login_details_and_click_next() throws Throwable {
    element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
    element.click();
    
}

@Then("^navigate to payment page$")
public void navigate_to_payment_page() throws Throwable {
	Alert alertbox=webdriver.switchTo().alert();
	alertbox.accept();
	
	
  webdriver.navigate().to("file:///C:/Users/akuma577/Downloads/Conferencebooking/PaymentDetails.html");
  
}



@Given("^payment page$")
public void payment_page() throws Throwable {
	
	
	String title=webdriver.getTitle();
	assertEquals("Payment Details", title);
	
	
    
	
	
}

@Given("^payment details$")
public void payment_details() throws Throwable {
	 webdriver.findElement(By.name("txtFN")).sendKeys("SHYAM");
	 webdriver.findElement(By.name("debit")).sendKeys("123456789");
	 webdriver.findElement(By.name("txtCvv")).sendKeys("123");
	 webdriver.findElement(By.name("month")).sendKeys("05");
	 webdriver.findElement(By.name("txtYear")).sendKeys("1998");
	 //webdriver.findElement(By.name("txtYear")).sendKeys("1998");
	 
	 
	
}

@When("^Submit validate payment details and click make payment$")
public void submit_validate_payment_details_and_click_make_payment() throws Throwable {
	 element=webdriver.findElement(By.id("btnPayment"));
	    element.click();
}

@Then("^display confirmation message$")
public void display_confirmation_message() throws Throwable {
	Alert alertbox=webdriver.switchTo().alert();
	alertbox.accept();
}
}


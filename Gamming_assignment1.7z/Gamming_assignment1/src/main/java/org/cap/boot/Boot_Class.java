package org.cap.boot;


import org.cap.exception.InvalidAgeException;
import org.cap.model.Registration;
import org.cap.service.IRegistrationService;
import org.cap.service.RegistrationServiceImpl;
import org.cap.view.UserInteraction;

public class Boot_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteraction userinteraction =new UserInteraction();
		IRegistrationService regservice=new RegistrationServiceImpl();
		
		Registration registration1=userinteraction.getdetails();

		Registration registration2;
		try {
			registration2 = regservice.createRegistration(registration1);
			if(registration2!=null)
				userinteraction.printAcknowledgement(registration2);
			else
				System.out.println("invalid reg details..plz try again...");
			System.exit(0);

		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}

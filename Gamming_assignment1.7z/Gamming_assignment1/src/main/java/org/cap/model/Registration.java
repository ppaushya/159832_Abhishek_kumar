package org.cap.model;

public class Registration {
int registrationId;
String custName;
String mobileNo;
Double regFees=1000.0;
int age;
Double actualRegFees;
public Registration() {
	
}
public Registration(int registrationId, String custName, String mobileNo, Double regFees, int age,
		Double actualRegFees) {
	super();
	this.registrationId = registrationId;
	this.custName = custName;
	this.mobileNo = mobileNo;
	this.regFees = regFees;
	this.age = age;
	this.actualRegFees = actualRegFees;
}
public int getRegistrationId() {
	return registrationId;
}
public void setRegistrationId(int registrationId) {
	this.registrationId = registrationId;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public Double getRegFees() {
	return regFees;
}
public void setRegFees(Double regFees) {
	this.regFees = regFees;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public Double getActualRegFees() {
	return actualRegFees;
}
public void setActualRegFees(Double actualRegFees) {
	this.actualRegFees = actualRegFees;
}
@Override
public String toString() {
	return "Registration [registrationId=" + registrationId + ", custName=" + custName + ", mobileNo=" + mobileNo
			+ ", regFees=" + regFees + ", age=" + age + ", actualRegFees=" + actualRegFees + "]";
}

}

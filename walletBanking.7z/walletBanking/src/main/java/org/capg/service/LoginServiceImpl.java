package org.capg.service;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginServiceImpl implements ILoginService {

	private ILoginDao loginDao = new LoginDaoImpl();

	@Override
	public Customer isValidLogin(LoginBean loginBean) {

		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {

		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {

		return loginDao.createAccount(account);
	}
}
